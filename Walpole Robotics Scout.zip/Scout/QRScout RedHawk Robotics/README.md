# QRScout

A QR Code Based Scouting System for FRC

[![Powered by Vercel](/powered-by-vercel.svg 'Powered by Vercel')](https://vercel.com/?utm_source=iraiders&utm_campaign=oss)
