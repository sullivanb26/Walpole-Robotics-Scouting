module.exports = {
  arrowParens: 'always',
  singleQuote: true,
  tabWidth: 2,
  semi: false,
  tailwindConfig: './tailwind.config.js',
}
